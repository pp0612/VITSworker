﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using VITScreateversion;
using VITSreplicateversion;

namespace VITSmonitor
{
    public class Program
    {
        public static void Main(string[] args)
        {
            WriteLog("VITSmonitor.txt", String.Format("{0} @ {1}", "Job started at", DateTime.Now));
            Console.WriteLine("Thread waiting");
            //Thread.Sleep(10000);

            WebClient client = new WebClient();
            //string url = "http://viewlte.apac.nsroot.net/VITS/retrivevitsjob";
            string url = "http://localhost:55124/VITS/retrivevitsjob";

            Byte[] requestedHTML;
            client.UseDefaultCredentials = true;
            requestedHTML = client.DownloadData(url);



            UTF8Encoding objUTF8 = new UTF8Encoding();
            string html = objUTF8.GetString(requestedHTML);
            html = html.Replace("<br/>", "\r\n");
            DataTable Receivedjob = new DataTable();





            string[] tableData = html.Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);

            var col = from cl in tableData[0].Split(",".ToCharArray())
                      select new DataColumn(cl);
            Receivedjob.Columns.AddRange(col.ToArray());
            (from st in tableData.Skip(1)
             select Receivedjob.Rows.Add(st.Split(",".ToCharArray()))).ToList();


            for (int j = 0; j < Receivedjob.Rows.Count; j++)
            {
                for (int i = 0; i < Receivedjob.Columns.Count; i++)
                {
                    Console.Write(Receivedjob.Columns[i].ColumnName + ":");
                    Console.WriteLine(Receivedjob.Rows[j].ItemArray[i]);
                }
            }


             //Console.ReadKey();

            DataRow[] Createjobs = Receivedjob.Select("Jobtype Like '%Create%' AND status Like '%scheduled%'");
            DataRow[] Createjobsinprogress = Receivedjob.Select("Jobtype Like '%Create%' AND status NOT Like '%scheduled%'");
            DataRow[] Replicatejobs = Receivedjob.Select("Jobtype Like '%Replicate%'");
            Console.WriteLine("Create jobs : " + Createjobs.Count());
            Console.WriteLine("Replicate jobs : " + Replicatejobs.Count());




            VITScreateversion.Program Newversion = new VITScreateversion.Program();
            VITSreplicateversion.Program Replicateversion = new VITSreplicateversion.Program();


            int totalColumns = Receivedjob.Columns.Count;
            if (Createjobs.Count() > 0)
            {



                foreach (DataRow p in Createjobs)
                {

                    Console.WriteLine(Bindparameter(p, totalColumns));

                    WriteLog("ConsoleLog.txt", String.Format("{0}", Bindparameter(p, totalColumns)));
                     Console.Write("Createjobs");
                    // Console.WriteLine(p.Field<string>("Jobid"));
                    Process.Start(Newversion.ReturnPath() + "\\VITScreateversion.exe", Bindparameter(p, totalColumns)).WaitForExit();
                    //String Parameter = "\"" + p.Field<string>("Jobid")+"\" " + "\"" + p.Field<string>("Jobtype") + "\"";
                    
                }

            }
            else if (Createjobsinprogress.Count() == 0)
            {
                foreach (DataRow p in Replicatejobs)
                {
                     Console.Write("Replicatejob");
                    
                    Process.Start(Replicateversion.ReturnPath() + "\\VITSreplicateversion.exe", Bindparameter(p, totalColumns)).WaitForExit();
                    
                }
            }

            
 
            

        }
        public static string GenerateCSV(DataTable dt)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                int count = 1;
                int totalColumns = dt.Columns.Count;
                foreach (DataColumn dr in dt.Columns)
                {
                    sb.Append(dr.ColumnName);

                    if (count != totalColumns)
                    {
                        sb.Append(",");
                    }

                    count++;
                }

                sb.AppendLine();

                string value = String.Empty;
                foreach (DataRow dr in dt.Rows)
                {
                    for (int x = 0; x < totalColumns; x++)
                    {
                        value = dr[x].ToString();

                        if (value.Contains(",") || value.Contains("\""))
                        {
                            value = '"' + value.Replace("\"", "\"\"") + '"';
                        }

                        sb.Append(value);

                        if (x != (totalColumns - 1))
                        {
                            sb.Append(",");
                        }
                    }

                    sb.AppendLine();
                }
            }
            catch (Exception ex)
            {
                // Do something
            }
            return sb.ToString();
        }
        public static string Bindparameter(DataRow dr, int totalColumns)
        {
            StringBuilder Parameter = new StringBuilder();
            string value = String.Empty;
            for (int x = 0; x < totalColumns; x++)
            {
                value = dr[x].ToString();
                value = "\"" + value + "\" ";
                Parameter.Append(value);
            }

            return Parameter.ToString();

        }
        public static bool WriteLog(string strFileName, string strMessage)
        {
            try
            {
                FileStream objFilestream = new FileStream(string.Format("{0}\\{1}", AppDomain.CurrentDomain.BaseDirectory, strFileName), FileMode.Append, FileAccess.Write);
                StreamWriter objStreamWriter = new StreamWriter((Stream)objFilestream);
                objStreamWriter.WriteLine(strMessage);
                objStreamWriter.Close();
                objFilestream.Close();
                objFilestream.Dispose();
                objStreamWriter.Close();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public string ReturnPath()
        {
            string folder = Environment.CurrentDirectory;
            return folder;
        }
    }
}

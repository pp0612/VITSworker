﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace VITSreplicateversion
{
    public class Program
    {
        public static void Main(string[] args)
        {
            foreach (string temp in args)
                Console.WriteLine(temp);

            WriteLog("VITSreplicateversion.txt", String.Format("{0} @ {1}", "Job started at", DateTime.Now));
            Console.WriteLine("Thread waiting");
           // Thread.Sleep(20000);
        }
        public static bool WriteLog(string strFileName, string strMessage)
        {
            try
            {
                FileStream objFilestream = new FileStream(string.Format("{0}\\{1}", AppDomain.CurrentDomain.BaseDirectory, strFileName), FileMode.Append, FileAccess.Write);
                StreamWriter objStreamWriter = new StreamWriter((Stream)objFilestream);
                objStreamWriter.WriteLine(strMessage);
                objStreamWriter.Close();
                objFilestream.Close();
                objFilestream.Dispose();
                objStreamWriter.Close();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public string ReturnPath()
        {
            string folder = Environment.CurrentDirectory;
            return folder;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using VITSmonitor;

namespace VITSschedulerservice
{
    public partial class VITSscheduler : ServiceBase
    {
        //Thread m_thread = null;

        public VITSscheduler()
        {
            InitializeComponent();
        }
        public void Ondebug()
        {
            OnStart(null);
        }

        //Thread Worker;
        AutoResetEvent StopRequest = new AutoResetEvent(false);
        Thread Worker = new Thread(DoWork);
        protected override void OnStart(string[] args)
        {

            
            Worker.Start();
            //DoWork(null);


        }

        protected override void OnStop()
        {
            StopRequest.Set();
            Worker.Join();
        }
        private static void DoWork(object arg)
        {
            // Worker thread loop

            for (; ; )
            {
                
                    VITSmonitor.Program Newmonitor = new VITSmonitor.Program();
                Process.Start(Newmonitor.ReturnPath() + "\\VITSmonitor.exe", null).WaitForExit();
                Thread.Sleep(300000);
                //WriteLog("ConsoleLog.txt", String.Format("{0} @ {1}", "Job started at", DateTime.Now));

            }
        }


  

        public static bool WriteLog(string strFileName, string strMessage)
        {
            try
            {
                FileStream objFilestream = new FileStream(string.Format("{0}\\{1}", AppDomain.CurrentDomain.BaseDirectory, strFileName), FileMode.Append, FileAccess.Write);
                StreamWriter objStreamWriter = new StreamWriter((Stream)objFilestream);
                objStreamWriter.WriteLine(strMessage);
                objStreamWriter.Close();
                objFilestream.Close();
                objFilestream.Dispose();
                objStreamWriter.Close();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


    }
}
